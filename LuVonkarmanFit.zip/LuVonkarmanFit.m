function [fitresult, gof] = LuVonkarmanFit(U,f)
% Syntax:
% [fitresult, gof] = LuVonkarmanFit(U,f)
%
% U is windspeed time history
% f is the sampling frequency
% Calculates Turbulence Length Scale through a curve fitting of spectral
% data over a Von Karman model.
% Variable L in the output shows the calculated Lu
% gof is the goodness of the fit
% 11/18/2015 Mohammadtaghi Moravej (mmora229@fiu.edu)
